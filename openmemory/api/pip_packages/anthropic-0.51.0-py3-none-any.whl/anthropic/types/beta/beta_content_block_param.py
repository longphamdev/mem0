# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import TypeAlias

from .beta_text_block_param import BetaTextBlockParam
from .beta_image_block_param import BetaImageBlockParam
from .beta_thinking_block_param import BetaThinkingBlockParam
from .beta_tool_use_block_param import BetaToolUseBlockParam
from .beta_base64_pdf_block_param import BetaBase64PDFBlockParam
from .beta_tool_result_block_param import BetaToolResultBlockParam
from .beta_server_tool_use_block_param import BetaServerToolUseBlockParam
from .beta_redacted_thinking_block_param import BetaRedactedThinkingBlockParam
from .beta_web_search_tool_result_block_param import BetaWebSearchToolResultBlockParam

__all__ = ["BetaContentBlockParam"]

BetaContentBlockParam: TypeAlias = Union[
    BetaTextBlockParam,
    BetaImageBlockParam,
    BetaToolUseBlockParam,
    BetaServerToolUseBlockParam,
    BetaWebSearchToolResultBlockParam,
    BetaToolResultBlockParam,
    BetaBase64PDFBlockParam,
    BetaThinkingBlockParam,
    BetaRedactedThinkingBlockParam,
]
